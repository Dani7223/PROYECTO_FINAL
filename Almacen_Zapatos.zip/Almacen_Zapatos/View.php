<?php

//Operaciones con la BBDD

require_once "LibreriaPDO.php";
require_once "Model.php";

$db = new DB("hotelgd");
$model = new Model();

class View
{
    public function mostrarCabecera()
    {
        echo '<nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="./img/zapatos.png" alt="Tu logo" width="50" height="130"
                    class="d-inline-block align-text-top">
            </a>
            <h2>ALMACÉN DE ZAPATOS </h2>
                <button class="btn btn-outline-warning mx-5" ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart" viewBox="0 0 16 16">
                <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
              </svg></button>
        </div>
    </nav>';
    }


    public function mostrarMenu()
    {


        if (isset($_SESSION['Cliente'])) {
            $sesionUsuario = "Cerrar Sesion";
            $url = "/Almacen/Almacen_Zapatos/index.php?cerrar";
            if ($_SESSION['Cliente']['email'] = "danieltajuelo@gmail.com") {
                $sesionUsuario = "ADMIN";
                $url = "/Almacen/Almacen_Zapatos/index.php?admin";
                echo "<script>
                $(document).ready(function() {
                    // Selecciona el elemento por su id y cambia el color de fondo
                    $('#miElemento').css('background-color', 'red'); // Cambia el color de fondo a rojo (puedes usar cualquier valor de color válido)
                  });
                        </script>
                ";
            }
        } else {
            $sesionUsuario = "Iniciar Sesión";
            $url = "/Almacen/Almacen_Zapatos/index.php?Identificate";
        }


        echo '   <nav class="navbar navbar-expand-lg" id="nav">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav d-flex w-100">
                <li class="nav-item dropdown flex-fill">
                    <a class="nav-link" href="http://localhost/Almacen/Almacen_Zapatos/index.php?H" id="menu-hombres" role="button" data-bs-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        Hombres
                    </a>
                </li>
                <li class="nav-item dropdown flex-fill">
                    <a class="nav-link" href="http://localhost/Almacen/Almacen_Zapatos/index.php?M" id="menu-mujeres" role="button" data-bs-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        Mujeres
                    </a>
                </li>
                <li class="nav-item dropdown flex-fill">
                    <a class="nav-link" href="http://localhost/Almacen/Almacen_Zapatos/index.php?P" id="menu-ninos" role="button" data-bs-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        Niños
                    </a>
                </li>
                <li class="nav-item flex-fill">
                    <a class="nav-link" href="' . $url . '">
                        ' . $sesionUsuario . '
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    
    
    ';
    }


    function mostrarCarousel()
    {
        echo '<div id="carouselExample" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="d-block w-100"
                    src="https://i8.amplience.net/i/jpl/desktop-top-banner-1920x840-2-adcd5c83314b4d4ef1af40f1d7393896?fmt=webp"
                    alt="First slide">
            </div>
            <div class="carousel-item">
                <img class="d-block w-100"
                    src="https://i8.amplience.net/i/jpl/desktop-top-banner-1920x840-9-5440ec7fbc491f922c58cc23e5c51862?fmt=webp"
                    alt="Second slide">
            </div>
            <div class="carousel-item">
                <img class="d-block w-100"
                    src="https://i8.amplience.net/i/jpl/desktop-top-banner-1920x840-6ed8da2d2cdeb1bd3a73f9dd572366ee?fmt=webp"
                    alt="Third slide">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Anterior</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Siguiente</span>
    </button>
    </div>';
    }


    function mostrarFormulario()
    {
        echo "<script>
                 let main = $('#main');

                 main.empty();
               </script>";

        echo '

        <div class="login-page bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                  <h3 class="mb-3">Inicie sesión</h3>
                    <div class="bg-white shadow rounded">
                        <div class="row">
                            <div class="col-md-7 pe-0">
                                <div class="form-left h-100 py-5 px-5">
                                    <form action="" class="row g-4" id="iniciar">
                                        <div class="form-group">
                                            <div class="col-12">
                                                <label>Correo electrónico<span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <div class="input-group-text"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                                                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
                                                    <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
                                                  </svg></div>
                                                    <input type="text" class="form-control" placeholder="Escriba su correo" id="email">
                                                </div>
                                            </div>

                                        </div>
                                        <div class="form-group">
                                            <div class="col-12">
                                                <label>Contraseña<span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <div class="input-group-text"><a href="#" onclick="mostrarContrasena()" style="text-decoration:none; color: #000;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-slash" viewBox="0 0 16 16">
                                                    <path d="M13.359 11.238C15.06 9.72 16 8 16 8s-3-5.5-8-5.5a7.028 7.028 0 0 0-2.79.588l.77.771A5.944 5.944 0 0 1 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.134 13.134 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755-.165.165-.337.328-.517.486l.708.709z"/>
                                                    <path d="M11.297 9.176a3.5 3.5 0 0 0-4.474-4.474l.823.823a2.5 2.5 0 0 1 2.829 2.829l.822.822zm-2.943 1.299.822.822a3.5 3.5 0 0 1-4.474-4.474l.823.823a2.5 2.5 0 0 0 2.829 2.829z"/>
                                                    <path d="M3.35 5.47c-.18.16-.353.322-.518.487A13.134 13.134 0 0 0 1.172 8l.195.288c.335.48.83 1.12 1.465 1.755C4.121 11.332 5.881 12.5 8 12.5c.716 0 1.39-.133 2.02-.36l.77.772A7.029 7.029 0 0 1 8 13.5C3 13.5 0 8 0 8s.939-1.721 2.641-3.238l.708.709zm10.296 8.884-12-12 .708-.708 12 12-.708.708z"/>
                                                  </svg></a></div>
                                                    <input type="password" class="form-control" placeholder="Escriba su contraseña" id="contra">
                                                </div>
                                            </div>
                                            <script>
                                            function mostrarContrasena() {
                                                event.preventDefault();
                                                var campoPassword = document.getElementById("contra");
                                                if (campoPassword.type === "password") {
                                                  campoPassword.type = "text";
                                                } else {
                                                  campoPassword.type = "password";
                           
                                                }
                                              }
                                            </script>
                                        </div>

    
                                            <div class="col-sm-6">
                                                <a href="http://localhost/Almacen/Almacen_Zapatos/index.php?Registro" class="text-primary">Quiero registrarme</a>
                                            </div>
    
                                                                                 
                                        <div id="novalido">
                                        
                                        </div>
    
                                        <div class="col-3">
                                        <a href="http://localhost/Almacen/Almacen_Zapatos/index.php" class="btn px-4 float-end mt-4" id="ver">Volver</a>
                                    </div>
    
                                            <div class="col-9">
                                                <button type="submit" class="btn px-4 float-end mt-4" id="ver">Confirmar</button>
                                            </div>
                                    </form>
                                </div>
                            </div>
                            <div class="col-md-5 ps-0">
                            <div class="form-right h-100 text-white text-center">
                                    <img class="h-100 w-100 img-fluid" src="./img/registro2.jpg">
                            </div>
                        </div>
                                               
                        </div> 
                    </div> 
                </div>    
            </div> 
        </div> 
    </div>                 
        ';
    }


    function mostrarFormularioRegistro()
    {
        echo "<script>
                 let main = $('#main');

                 main.empty();
               </script>";

        echo '

        <div class="register-page bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <h3 class="mb-3">Regístrate</h3>
                    <div class="bg-white shadow rounded">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-left h-100 py-5 px-5">
                                    <form action="" class="row g-4" id="registrar" novalidate>
                                        <div class="form-group col-md-6">
                                            <label>Nombre<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Ingresa tu nombre" id="nombre" required pattern="[A-Z,a-z]{3,30}">
                                            <div class="invalid-feedback text-danger ">Rellene el nombre correctamente</div>
                                            <div class="valid-feedback ">Correcto</div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Apellido<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control-sm" placeholder="Ingresa tu apellido" id="apellido" required pattern="[A-Z,a-z]{3,30}">
                                            <div class="invalid-feedback text-danger">Rellene el apellido correctamente</div>
                                            <div class="valid-feedback ">Correcto</div>
                                        </div>

                                        <div class="form-group col-md-6">
                                        <label>Dni<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Ingresa tu dni" id="dni" required pattern="[0-9]{8}[A-Za-z]">
                                        <div class="invalid-feedback text-danger">Rellene el dni correctamente</div>
                                        <div class="valid-feedback ">Correcto</div>
                                    </div>

                                    <div class="form-group col-md-6">
                                    <label>Teléfono<span class="text-danger">*</span></label>
                                    <input type="tel" class="form-control" placeholder="Ingresa tu número de teléfono" id="telefono" required pattern="[0-9]{9}">
                                    <div class="invalid-feedback text-danger ">Rellene el teléfono correctamente(9 numeros)</div>
                                    <div class="valid-feedback ">Correcto</div>
                                </div>
                                        <div class="form-group col-md-12">
                                            <label>Correo electrónico<span class="text-danger">*</span></label>
                                            <input type="email" class="form-control" placeholder="Ingresa tu correo electrónico" id="email" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" required>
                                            <div class="invalid-feedback text-danger ">Rellene el correo correctamente</div>
                                            <div class="valid-feedback ">Correcto</div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Contraseña<span class="text-danger">*</span></label>
                                            <input type="password" class="form-control" placeholder="Ingresa una contraseña" id="contrasena" required pattern="[A-Z,a-z,0-9]{5,35}">
                                            <div class="invalid-feedback text-danger ">La contraseña debe tener 5 caracteres mínimo</div>
                                            <div class="valid-feedback ">Correcto</div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Código postal<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Ingresa tu CP" id="codigo-postal" required pattern="[0-9]{3,8}">
                                            <div class="invalid-feedback text-danger ">Rellene su CP correctamente</div>
                                            <div class="valid-feedback ">Correcto</div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Ciudad<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Ingresa tu ciudad" id="ciudad" required>
                                            <div class="invalid-feedback text-danger ">Rellene su ciudad correctamente</div>
                                            <div class="valid-feedback ">Correcto</div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>País<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Ingresa tu país" id="pais" required>
                                            <div class="invalid-feedback text-danger ">Rellene su ciudad correctamente</div>
                                            <div class="valid-feedback ">Correcto</div>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label>Dirección<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Ingresa tu dirección" id="direccion" required>
                                            <div class="invalid-feedback text-danger ">Rellene correctamente su dirección</div>
                                            <div class="valid-feedback ">Correcto</div>
                                        </div>

                                        <div class="col-3">
                                        <a href="http://localhost/Almacen/Almacen_Zapatos/index.php?Identificate" class="btn px-4 float-end mt-4" id="ver">Volver</a>
                                    </div>
                                        <div class="col-9">
                                            <button type="submit" class="btn float-end mt-4" id="ver">Registrarse</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-right h-100 text-white text-center">
                                    <img class="h-100 w-100 img-fluid" src="./img/registro3.jpg">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
        ';
    }

    function mostrarZapa()
    {

        echo "<script>
        let main = $('#main');

        main.empty();
      </script>";


        echo '';
    }
}
