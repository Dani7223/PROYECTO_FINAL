<?php

require_once 'Model.php';
require_once 'View.php';

class Controller
{
    private $model;
    private $view;
    private $db;

    public function __construct()
    {
        $this->model = new Model();
        $this->view = new View();
        $this->db = new DB("almacen_zapatos");
    }



    public function mostrarIndex($db)
    {
        $this->view->mostrarCabecera();
        $this->view->mostrarMenu();
        $this->view->mostrarCarousel();
        $this->model->mostrarOfertas($db);
        $this->model->mostrarNovedades($db);
    }


    public function mostrarLogin()
    {
        $this->view->mostrarFormulario();
    }

    public function mostrarDetalleZapa()
    {
        $this->view->mostrarZapa();
    }

    public function recuperarFotos($id, $db)
    {
        $this->model->consultarFotos($id, $db);
    }

    public function mostrarRegistro(){

        $this->view->mostrarFormularioRegistro();
    }
}
