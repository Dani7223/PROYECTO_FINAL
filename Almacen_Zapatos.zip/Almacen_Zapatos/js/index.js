$("#ver").css({

  "background-color": "#FCF906",
  "justify-content": "center"

});


let formSesion = document.getElementById("iniciar");

if (formSesion !== null) {
  formSesion.addEventListener("submit", function (event) {
    // Prevenir que el formulario se envíe automáticamente
    event.preventDefault();

    // Validar el formulario
    if (this.checkValidity() === false) {
      event.stopPropagation();
      this.classList.add('was-validated');
    } else {

      let email = document.getElementById("email").value;

      let contra = document.getElementById("contra").value;

      if (email === "") {
        $('#novalido').empty();
        $('#novalido').append(`<h5 style="color:red;">El correo es necesario</h5>`)
      } else if (contra === "") {
        $('#novalido').empty();
        $('#novalido').append(`<h5 style="color:red;">La contraseña es obligatoria!!</h5>`)
      } else {

        $.ajax({
          url: './Peticiones.php?type=sesion',
          type: 'POST',
          data: {
            email: email,
            contra: contra
          },
          success: function (response) {
            console.log(response)
            if (response.exists) {

              location.href = '/Almacen/Almacen_Zapatos/index.php';
            } else {
              $('#novalido').empty();
              $('#novalido').append(`<h5 style="color:red;">El correo o contraseña es incorrecto</h5>`)
            }
          },
          error: function () {
          }
        });

      }

    }
  }, false);
}







let formRegistro = document.getElementById("iniciar");

if (formRegistro !== null) {
  formRegistro.addEventListener("submit", function (event) {
    // Prevenir que el formulario se envíe automáticamente
    event.preventDefault();

    // Validar el formulario
    if (this.checkValidity() === false) {
      event.stopPropagation();
      this.classList.add('was-validated');
    } else {

      let email = document.getElementById("email").value;

      let contra = document.getElementById("contra").value;

      if (email === "") {
        $('#novalido').empty();
        $('#novalido').append(`<h5 style="color:red;">El correo es necesario</h5>`)
      } else if (contra === "") {
        $('#novalido').empty();
        $('#novalido').append(`<h5 style="color:red;">La contraseña es obligatoria!!</h5>`)
      } else {

        $.ajax({
          url: './Peticiones.php?type=sesion',
          type: 'POST',
          data: {
            email: email,
            contra: contra
          },
          success: function (response) {
            console.log(response)
            if (response.exists) {

              location.href = '/Almacen/Almacen_Zapatos/index.php';
            } else {
              $('#novalido').empty();
              $('#novalido').append(`<h5 style="color:red;">El correo o contraseña es incorrecto</h5>`)
            }
          },
          error: function () {
          }
        });

      }

    }
  }, false);
}