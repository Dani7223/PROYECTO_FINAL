$("#ver").css({

    "background-color": "#FCF906",
    "justify-content": "center"

});
