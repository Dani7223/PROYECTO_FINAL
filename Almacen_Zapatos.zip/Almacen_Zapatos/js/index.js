$("#ver").css({

  "background-color": "#FCF906",
  "justify-content": "center"

});


let formSesion = document.getElementById("iniciar");

if (formSesion !== null) {
  formSesion.addEventListener("submit", function (event) {
    // Prevenir que el formulario se envíe automáticamente
    event.preventDefault();

    // Validar el formulario
    if (this.checkValidity() === false) {
      event.stopPropagation();
      this.classList.add('was-validated');
    } else {

      let email = document.getElementById("email").value;

      let contra = document.getElementById("contra").value;

      if (email === "") {
        $('#novalido').empty();
        $('#novalido').append(`<h5 style="color:red;">El correo es necesario</h5>`)
      } else if (contra === "") {
        $('#novalido').empty();
        $('#novalido').append(`<h5 style="color:red;">La contraseña es obligatoria!!</h5>`)
      } else {

        $.ajax({
          url: './Peticiones.php?type=sesion',
          type: 'POST',
          data: {
            email: email,
            contra: contra
          },
          success: function (response) {
            console.log(response)
            if (response.exists) {

              location.href = '/Almacen/Almacen_Zapatos/index.php';
            } else {
              $('#novalido').empty();
              $('#novalido').append(`<h5 style="color:red;">El correo o contraseña es incorrecto</h5>`)
            }
          },
          error: function () {
          }
        });

      }

    }
  }, false);
}



document.getElementById('registrar').addEventListener("submit", function (event) {


  $("#registrar").addClass('was-validated');

  if (this.checkValidity() === false) {
    event.preventDefault();
    event.stopPropagation();
  } else {
    let nombre = document.getElementById("nombre").value;

    let apellido = document.getElementById("apellido").value;

    let email = document.getElementById("email").value;

    let contrasena = document.getElementById("contrasena").value;

    let telefono = document.getElementById("telefono").value;

    let direccion = document.getElementById("direccion").value;

    let pais = document.getElementById("pais").value;

    let ciudad = document.getElementById("ciudad").value;

    let codigo = document.getElementById("codigo-postal").value;

    $.ajax({
      url: './Peticiones.php?type=registro',
      type: 'POST',
      data: {
        nombre: nombre,
        apellido: apellido,
        email: email,
        contrasena: contrasena,
        telefono: telefono,
        direccion: direccion,
        pais: pais,
        ciudad:ciudad,
        codigo: codigo,
      },
      success: function (response) {
        console.log(response)
        if (response.exists) {
         
          
        }
      },
      error: function () {
      }
    });

  }



});


// let formRegistro = document.getElementById("registrar");

// if (formRegistro !== null) {
//   formRegistro.addEventListener("submit", function (event) {
//     // Prevenir que el formulario se envíe automáticamente
//     event.preventDefault();

//     // Validar el formulario
//     if (this.checkValidity() === false) {
//       event.stopPropagation();
//       $("#registrar").addClass('was-validated');
//     } else {


      // if (email === "") {
      //   $('#novalido').empty();
      //   $('#novalido').append(`<h5 style="color:red;">El correo es necesario</h5>`)
      // } else if (contra === "") {
      //   $('#novalido').empty();
      //   $('#novalido').append(`<h5 style="color:red;">La contraseña es obligatoria!!</h5>`)
      // } else {

      //   $.ajax({
      //     url: './Peticiones.php?type=sesion',
      //     type: 'POST',
      //     data: {
      //       email: email,
      //       contra: contra
      //     },
      //     success: function (response) {
      //       console.log(response)
      //       if (response.exists) {

      //         location.href = '/Almacen/Almacen_Zapatos/index.php';
      //       } else {
      //         $('#novalido').empty();
      //         $('#novalido').append(`<h5 style="color:red;">El correo o contraseña es incorrecto</h5>`)
      //       }
      //     },
      //     error: function () {
      //     }
      //   });

      // }

//     }
//   }, false);
// }