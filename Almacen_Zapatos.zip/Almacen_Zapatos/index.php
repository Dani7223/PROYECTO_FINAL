<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="./img/entrenadores.png" type="image/x-icon">
  <title>Tienda de Zapatos en línea</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-LSHI3wpZbfNrqL2x1aJBKBysvMwrvFNMyLh5dmV/2D9A8LEhoGIYVZD94CNMUUel/93+v9E9JSRfFmLk4eUFBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="https://fonts.googleapis.com/css2?family=Inconsolata&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="./css/style.css">
</head>

<body>

  <?php

  session_start();

  require_once("controller.php");

  $db = new DB("almacen_zapatos");

  $controller = new Controller();

  echo "<main id='main'>";

  $controller->mostrarIndex($db);

  echo "</main>";

  if (isset($_GET['Identificate'])) {

    $controller->mostrarLogin();
  }


  if (isset($_GET['Registro'])) {
    $controller->mostrarRegistro();
  }


  if (isset($_GET['cerrar'])) {
    session_destroy();

    echo '
        <script>
        window.location.href = "http://localhost/Almacen/Almacen_Zapatos/index.php"
        </script>';
  }


  if (isset($_GET['H'])) {
    session_destroy();

    echo '
      <script>
      window.location.href = "http://localhost/Almacen/Almacen_Zapatos/index.php"
      </script>';
  } else if (isset($_GET['M'])) {
  } else if (isset($_GET['P'])) {
  }


  if ((isset($_GET['mas']))) {

    $id = $_GET['Id'];

    echo '<script>

  $.ajax({
    url: "./Peticiones.php?type=especifica", // Ruta del archivo en el servidor que verifica la disponibilidad del correo electrónico
    type: "POST",
    data: { Id : ' . $id . ' },
    success: function (response) {
      console.log(response)
      if (response.exists) {
        $("#main").empty();
        $("#main").append(`<div class="container mt-5">
        <div class="row">
          <div class="col-md-6">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
              <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
              </ol>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="./img/520.jpg" class="d-block w-100" alt="Imagen 1">
                </div>
                <div class="carousel-item" id="zapa">

                </div>
              </div>
              <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Anterior</span>
              </a>
              <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Siguiente</span>
              </a>
            </div>
          </div>
          <div class="col-md-6">
            <div id="zapa4">
          <p>HOLA</p>
            </div>
            <div id="precio">

            </div>
            <p>Precio: $99.99</p>
            <div class="form-group">
              <label for="talla">Talla:</label>
              <select class="form-control-sm" id="talla">
                <option>36</option>
                <option>37</option>
                <option>38</option>
                <option>39</option>
                <option>40</option>
              </select>
            </div>
            <button type="button" class="btn btn-primary">Comprar</button>
          </div>
        </div>
      </div>`);
        for (let i = 0; i < response.exists.length; i+=8) {
          console.log(response.exists[i+1]);
          let prueba = $("#zapa4")
          prueba.append("<p>HOLA MUNDO</p>");
          console.log(prueba);
        }
      } else {
        
      }
    },
    error: function () {
    }
  });
        </script>';
  }


  ?>

  <footer class="bg-dark text-white py-5 mt-5">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <h6 class="mb-4">Sobre nosotros</h6>
          <p class="text-muted">En Almacén de Zapatos , nos enorgullece ofrecer una amplia selección de zapatillas sostenibles para todos los públicos. Todos nuestros productos están fabricados con materiales de origen responsable y producción ética. Además, nuestras zapatillas están diseñadas para ser accesibles y cómodas para personas de todas las edades y habilidades. ¡Encuentra tu par perfecto hoy mismo!</p>
        </div>
        <div class="col-md-4">
          <h6 class="mb-4">Contacto</h6>
          <ul class="list-unstyled">
            <li><i class="fas fa-map-marker-alt mr-2"></i>123 Calle Falsa, Springfield</li>
            <li><i class="fas fa-phone-alt mr-2"></i>+34 620 12 13 14</li>
            <li><i class="fas fa-envelope mr-2"></i>info@almacen.com</li>
            <li><i class="fas fa-envelope mr-2"></i>Horario de atención al cliente: Lunes a Viernes de 9:00 a 17:00 p.m.</li>
            <li><i class="fas fa-envelope mr-2"></i>Para cualquier consulta o comentario adicional, no dudes en contactarnos a través de nuestras redes sociales.</li>

          </ul>
        </div>
        <div class="col-md-4">
          <h6 class="mb-4">Síguenos</h6>
          <div class="d-flex justify-content-between">
            <li class="list-inline-item d-inline-block"><a href="https://www.instagram.com/"><img src="./img/insta.png" class="rounded-circle img-thumbnail w-50 h-100"></a></li>
            <li class="list-inline-item d-inline-block"><a href="https://twitter.com/"><img src="./img/twit.png" class="rounded-circle img-thumbnail w-50 h-100"></a></li>
            <li class="list-inline-item d-inline-block"><a href="https://es-es.facebook.com/"><img src="./img/face.png" class="rounded-circle img-thumbnail w-50 h-100"></a></li>
          </div>
        </div>


      </div>
      <hr class="my-4">
      <div class="row">
        <div class="col-md-6">
          <p class="text-muted mb-0">© 2023 Venta de Zapatillas Online. Todos los derechos reservados.</p>
        </div>
        <div class="col-md-6">
          <p class="text-muted float-md-right mb-0"><a href="#">Política de privacidad</a> | <a href="#">Términos y condiciones</a></p>
        </div>
      </div>
    </div>
  </footer>



</body>

<script src="./js/index.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>

</html>