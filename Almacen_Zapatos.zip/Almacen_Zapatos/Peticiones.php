<?php

require_once("./LibreriaPDO.php");

$select = $_GET['type'];

$db = new DB('almacen_zapatos');

function existeUsuario($db, $email, $contra)
{

    $param = array();

    $param[':correo'] = $email;

    $param[':contra'] = $contra;

    $consulta = "select count(*) as total from usuarios where correo_electronico = :correo and contra = :contra";

    $db->ConsultaDatos($consulta, $param);

    $total = $db->filas[0]['total'];

    return $total;
}


function registrarUsuario($db,$nombre,$apellido,$dni,$email,$ciudad,$contrasena,$telefono,$direccion,$pais,$codigo)
{

    $param = array();

    $param[':nombre'] = $nombre;

    $param[':apellido'] = $apellido;

    $param[':dni'] = $dni;

    $param[':email'] = $email;

    $param[':contrasena'] = $contrasena;

    $param[':telefono'] = $telefono;

    $param[':ciudad'] = $ciudad;

    $param[':direccion'] = $direccion;

    $param[':codigo'] = $codigo;


    $consulta = "INSERT INTO `usuarios`(`Id`, `DNI`, `nombre_cliente`, `apellidos_cliente`, `telefono`, `correo_electronico`, `contra`, `Codigo_Postal`, `Localidad`, `direccion_envio`)
     VALUES (NULL,':dni',':nombre',':apellido',':telefono',':email',':contrasena',':codigo',':ciudad',':direccion')";

    $db->ConsultaDatos($consulta, $param);

    $total = $db->filas[0]['total'];

    return $total;
}

function buscarZapatilla($db, $id)
{
    $param = array();

    $param[':id'] = $id;

    $consulta = "select * from producto where id_producto = :id";

    $db->ConsultaDatos($consulta, $param);

    $array = array();

    foreach ($db->filas as $fila) {
        $array[] = base64_encode($fila['Foto']);
        $array[] = $fila['Precio'];
        $array[] = $fila['Modelo'];
        $array[] = $fila['Descripcion'];
        $array[] = $fila['Id_Marca'];
        $array[] = $fila['Hombre'];
        $array[] = $fila['Mujer'];
        $array[] = $fila['Peque'];
    }

    return $array;
}

if ($select === "sesion") {
    $email = $_POST['email'];
    $contra = $_POST['contra'];

    $usuario =  existeUsuario($db, $email, $contra);


    if ($usuario == 1) {
        session_start();
        $_SESSION['Cliente']['email'] = $email;
        $esta = true;
    } else {
        $esta = false;
    }

    $response = array('exists' => $esta);

    header('Content-Type: application/json');
    echo json_encode($response);
} else if ($select === "especifica") {
    $id = $_POST['Id'];
    $array = buscarZapatilla($db, $id);

    $response = array('exists' => $array);

    header('Content-Type: application/json');
    echo json_encode($response);
} else if ($select === "registro") {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $dni = $_POST['dni'];
    $email = $_POST['email'];
    $contrasena = $_POST['contrasena'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];
    $pais = $_POST['pais'];
    $codigo = $_POST['codigo'];
    $ciudad = $_POST['ciudad'];

    $usuario =  existeUsuario($db, $email, $contra);

    if ($usuario == 1) {
        $esta = true;

        $response = array('exists' => $esta);
 
    } else {
        $esta=registrarUsuario($db,$nombre,$apellido,$dni,$email,$ciudad,$contrasena,$telefono,$direccion,$pais,$codigo);
    }


    header('Content-Type: application/json');
    echo json_encode($response);
}
