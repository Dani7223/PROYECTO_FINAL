<?php

require_once("./LibreriaPDO.php");

$select = $_GET['type'];

$db = new DB('almacen_zapatos');

function existeUsuario($db, $email, $contra)
{

    $param = array();

    $param[':correo'] = $email;

    $param[':contra'] = $contra;

    $consulta = "select count(*) as total from usuarios where correo_electronico = :correo and contra = :contra";

    $db->ConsultaDatos($consulta, $param);

    $total = $db->filas[0]['total'];

    return $total;
}

function buscarZapatilla($db, $id)
{
    $param = array();

    $param[':id'] = $id;

    $consulta = "select * from producto where id_producto = :id";

    $db->ConsultaDatos($consulta, $param);

    $array = array();

    foreach ($db->filas as $fila) {
        $array[] = base64_encode($fila['Foto']);
        $array[] = $fila['Precio'];
        $array[] = $fila['Modelo'];
        $array[] = $fila['Descripcion'];
        $array[] = $fila['Id_Marca'];
        $array[] = $fila['Hombre'];
        $array[] = $fila['Mujer'];
        $array[] = $fila['Peque'];
    }

    return $array;
}

if ($select === "sesion") {
    $email = $_POST['email'];
    $contra = $_POST['contra'];

    $usuario =  existeUsuario($db, $email, $contra);


    if ($usuario == 1) {
        session_start();
        $_SESSION['Cliente']['email'] = $email;
        $esta = true;
    } else {
        $esta = false;
    }

    $response = array('exists' => $esta);

    header('Content-Type: application/json');
    echo json_encode($response);
} else if ($select === "especifica") {
    $id = $_POST['Id'];
    $array = buscarZapatilla($db, $id);

    $response = array('exists' => $array);

    header('Content-Type: application/json');
    echo json_encode($response);
}
